package rummikub;

import javax.swing.JLabel;

/**
 *
 * @author 
 */
public class Ficha {
    private int ficha;
    private String color;
    private JLabel label;

    public Ficha(int ficha, String color, JLabel label) {
        this.ficha = ficha;
        this.color = color;
        this.label = label;
    }

    public int getFicha() {
        return ficha;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Ficha{" + "ficha= " + ficha + ", color= " + color + '}';
    }
}