package rummikub;

/**
 *
 * @author 
 */
public class Rummikub {

    public static void main(String[] args) {
        Ventana ventana = new Ventana();
        ventana.setVisible(true);
    }
}