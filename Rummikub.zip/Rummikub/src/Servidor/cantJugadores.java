package Servidor;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author 
 */
public class cantJugadores extends JDialog{
    
    private JTextField textField;
    private String entradaTexto;

    public cantJugadores(JFrame parent) {
        super(parent, "¿De cuántos jugadores quiere su sala?", true); // El último parámetro (true) hace que el cuadro de diálogo sea modal.

        textField = new JTextField(26);
        JButton aceptarButton = new JButton("Aceptar");

        aceptarButton.addActionListener(e -> {
            entradaTexto = textField.getText();
            dispose(); // Cierra el cuadro de diálogo.
        });

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(textField, BorderLayout.NORTH);
        panel.add(aceptarButton, BorderLayout.CENTER);

        getContentPane().add(panel);
        pack();
        setLocationRelativeTo(parent); // Centra el cuadro de diálogo en la ventana principal.
    }

    public String mostrarCuadroDeDialogo() {
        entradaTexto = null;
        setVisible(true); // Hace visible el cuadro de diálogo y espera a que se cierre.

        return entradaTexto;
    }
}