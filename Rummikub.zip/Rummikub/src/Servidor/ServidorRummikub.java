package Servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
//import java.util.logging.Level;
//import java.util.logging.Logger;

/**
 *
 * @author 
 */
public class ServidorRummikub{
    
    JFrameServidor ventana;
    Socket jugador1;
    Socket jugador2;
    Socket jugador3;
    Socket jugador4;
    public ArrayList<threadServidor> hilosserver;
    
    public ServidorRummikub(JFrameServidor padre){
        this.ventana = padre;
    }
    
    public void runServer(){
        try {
            cantJugadores dialog = new cantJugadores(ventana);
            String textoIngresado = dialog.mostrarCuadroDeDialogo();
            
            //crea el socket servidor para aceptar dos conexiones
            ServerSocket serv = new ServerSocket(8081);
            ventana.mostrar(".::Servidor Activo");
            ventana.mostrar(".::Esperando jugadores");

            if ("2".equals(textoIngresado)) {
                // espera primer cliente
                jugador1 = serv.accept();
                ventana.mostrar(".::Primer Jugador Aceptado");
                threadServidor user1 = new threadServidor(jugador1, this,1);
                user1.start();

                // espera segundo cliente
                jugador2 = serv.accept();
                ventana.mostrar(".::Segundo Jugador Aceptado");
                threadServidor user2 = new threadServidor(jugador2, this,2);
                user2.start();
                
                user1.enemigo1 = user2;
                user2.enemigo2 = user1;
            }
            if ("3".equals(textoIngresado)) {
                jugador1 = serv.accept();
                ventana.mostrar(".::Primer Jugador Aceptado");
                threadServidor user1 = new threadServidor(jugador1, this,1);
                user1.start();

                // espera segundo cliente
                jugador2 = serv.accept();
                ventana.mostrar(".::Segundo Jugador Aceptado");
                threadServidor user2 = new threadServidor(jugador2, this,2);
                user2.start();

                // espera tercer cliente
                jugador3 = serv.accept();
                ventana.mostrar(".::Tercer Jugador Aceptado");
                threadServidor user3 = new threadServidor(jugador3, this,3);
                user3.start();
                
                user1.enemigo1 = user2;
                user1.enemigo2 = user3;
                user2.enemigo1 = user1;
                user2.enemigo2 = user3;
                user3.enemigo1 = user1;
                user3.enemigo2 = user2;
            }
            if ("4".equals(textoIngresado)) {
                // espera primer cliente
                jugador1 = serv.accept();
                ventana.mostrar(".::Primer Jugador Aceptado");
                threadServidor user1 = new threadServidor(jugador1, this,1);
                user1.start();

                // espera segundo cliente
                jugador2 = serv.accept();
                ventana.mostrar(".::Segundo Jugador Aceptado");
                threadServidor user2 = new threadServidor(jugador2, this,2);
                user2.start();

                // espera tercer cliente
                jugador3 = serv.accept();
                ventana.mostrar(".::Tercer Jugador Aceptado");
                threadServidor user3 = new threadServidor(jugador3, this,3);
                user3.start();

                // espera cuarto cliente
                jugador4 = serv.accept();
                ventana.mostrar(".::Cuarto Jugador Aceptado");
                threadServidor user4 = new threadServidor(jugador4, this,4);
                user4.start();
                
                user1.enemigo1 = user2;
                user1.enemigo2 = user3;
                user1.enemigo3 = user4;
                user2.enemigo1 = user1;
                user2.enemigo2 = user3;
                user2.enemigo3 = user4;
                user3.enemigo1 = user1;
                user3.enemigo2 = user2;
                user3.enemigo3 = user4;
                user4.enemigo1 = user1;
                user4.enemigo2 = user2;
                user4.enemigo3 = user3;
            }
            
            while (true){
            }
            
        } catch (IOException ex) {
            ventana.mostrar("ERROR ... en el servidor");
        }
    }
}